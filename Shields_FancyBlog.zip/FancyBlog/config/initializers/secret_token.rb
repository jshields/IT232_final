# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Blog::Application.config.secret_key_base = '3944a7ff12db780262f70ff1182f8936e0b10e891711feb78ef9b1260a0e93453fd18f7d83f917cefa8327efaa7bed74dc98a1df8e969694b18a68e1b1e5cd6c'
